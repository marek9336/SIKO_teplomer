
# 🌐 SIKO Teploměr – Web GUI verze (ESP32)

## ✅ Funkce
- Zobrazení času, data, hvězdného datumu
- Teplota z čidla DS18B20 na GPIO 4
- Historie teploty ve formě grafu (24h)
- Obrázky s meme dle teploty
- Error obrázek, pokud je čidlo odpojeno
- Web na `/`, API `/api/*`
- Nastavitelný hostname a výpis IP na sériovou linku

## 🌍 Webové rozhraní
Dostupné na `/` (např. `http://192.168.20.115/`), obsahuje:
- Teplotu
- Hodiny a datum
- Hvězdné datum
- Meme obrázek dle aktuální teploty
- Graf 24h historie

## 🔧 API
- `/api/temp` – JSON s teplotou a kalibrací
- `/api/status` – info o verzi, rozsahu, uptime
- `/api/history` – 288 hodnot (každých 5 minut)
- `/api/meme` – aktuální obrázek dle teploty
- `/api/setcomfort` – POST pro změnu komfortu/kalibrace

## ⚙️ secrets.h
```cpp
#define WIFI_SSID "TvojeWiFi"
#define WIFI_PASSWORD "Heslo"
#define GITHUB_USER "marek9336"
#define GITHUB_REPO "SIKO_teplomer"
#define GITHUB_BASE_URL "https://" GITHUB_USER ".github.io/" GITHUB_REPO "/Pictures/"
```

## 🖥️ PowerShell
```powershell
$response = Invoke-RestMethod -Uri "http://IP_ESP/api/temp"
$status = Invoke-RestMethod -Uri "http://IP_ESP/api/status"
Write-Host "Teplota: $($response.temperature) °C (Kalibrace: $($response.calibration))"
Write-Host "Verze: $($status.version)"
```
